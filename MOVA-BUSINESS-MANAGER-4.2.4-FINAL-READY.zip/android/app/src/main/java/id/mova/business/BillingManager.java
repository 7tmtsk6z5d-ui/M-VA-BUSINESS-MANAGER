package id.mova.business;

import android.app.Activity;
import android.content.Context;
import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.ProductDetails;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.PurchasesUpdatedListener;
import com.android.billingclient.api.QueryProductDetailsParams;
import com.android.billingclient.api.QueryPurchasesParams;
import com.android.billingclient.api.AcknowledgePurchaseParams;
import com.android.billingclient.api.PendingPurchasesParams;

import java.util.Collections;
import java.util.List;

public final class BillingManager implements PurchasesUpdatedListener {
    public interface Listener { void onPurchase(String productId,String purchaseToken); void onBillingError(String message); }
    private final BillingClient billing;
    private final Listener listener;
    private Activity activity;

    public BillingManager(Context context,Listener listener){
        this.listener=listener;
        billing=BillingClient.newBuilder(context).setListener(this).enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build()).enableAutoServiceReconnection().build();
        billing.startConnection(new BillingClient.BillingClientStateListener(){
            @Override public void onBillingSetupFinished(BillingResult r){ if(r.getResponseCode()==BillingClient.BillingResponseCode.OK)queryActive(); }
            @Override public void onBillingServiceDisconnected(){}
        });
    }
    public void setActivity(Activity a){activity=a;}
    public void purchase(String productId){
        if(activity==null){listener.onBillingError("Aktivitas billing belum siap.");return;}
        QueryProductDetailsParams params=QueryProductDetailsParams.newBuilder()
          .setProductList(Collections.singletonList(QueryProductDetailsParams.Product.newBuilder().setProductId(productId).setProductType(BillingClient.ProductType.SUBS).build())).build();
        billing.queryProductDetailsAsync(params,(result,details)->{
            if(result.getResponseCode()!=BillingClient.BillingResponseCode.OK||details==null||details.isEmpty()){listener.onBillingError("Produk MŌVA Pro tidak tersedia di Google Play.");return;}
            ProductDetails d=details.get(0);
            List<ProductDetails.SubscriptionOfferDetails> offers=d.getSubscriptionOfferDetails();
            if(offers==null||offers.isEmpty()){listener.onBillingError("Penawaran MŌVA Pro belum tersedia.");return;}
            BillingFlowParams.ProductDetailsParams pd=BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(d).setOfferToken(offers.get(0).getOfferToken()).build();
            BillingResult launchResult = billing.launchBillingFlow(activity,BillingFlowParams.newBuilder().setProductDetailsParamsList(Collections.singletonList(pd)).build());
            if (launchResult.getResponseCode()!=BillingClient.BillingResponseCode.OK) listener.onBillingError(launchResult.getDebugMessage());
        });
    }
    public void queryActive(){
        billing.queryPurchasesAsync(QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.SUBS).build(),(r,purchases)->{
            if(r.getResponseCode()!=BillingClient.BillingResponseCode.OK||purchases==null)return;
            for(Purchase p:purchases){
                if(p.getPurchaseState()==Purchase.PurchaseState.PURCHASED){
                    for(String id:p.getProducts())listener.onPurchase(id,p.getPurchaseToken());
                }
            }
        });
    }
    @Override public void onPurchasesUpdated(BillingResult r,List<Purchase> purchases){
        if(r.getResponseCode()==BillingClient.BillingResponseCode.OK&&purchases!=null){
            for(Purchase p:purchases){
                if(p.getPurchaseState()==Purchase.PurchaseState.PURCHASED){
                    for(String id:p.getProducts())listener.onPurchase(id,p.getPurchaseToken());
                }
            }
            return;
        }
        if(r.getResponseCode()!=BillingClient.BillingResponseCode.USER_CANCELED)listener.onBillingError(r.getDebugMessage());
    }
    public void acknowledge(String purchaseToken){
        if(purchaseToken==null||purchaseToken.isEmpty())return;
        billing.acknowledgePurchase(AcknowledgePurchaseParams.newBuilder().setPurchaseToken(purchaseToken).build(),(r)->{});
    }
    public void destroy(){billing.endConnection();}
}
