package id.mova.business;

import android.content.Context;
import java.util.concurrent.CopyOnWriteArrayList;

public final class PaymentEventBus {
    public interface Listener { void onPayment(String json); }
    private static final CopyOnWriteArrayList<Listener> listeners=new CopyOnWriteArrayList<>();
    public static void register(Listener l){if(l!=null&&!listeners.contains(l))listeners.add(l);}
    public static void unregister(Listener l){listeners.remove(l);}
    public static void publish(Context c,String json){for(Listener l:listeners){try{l.onPayment(json);}catch(Exception ignored){}}}
    private PaymentEventBus(){}
}
