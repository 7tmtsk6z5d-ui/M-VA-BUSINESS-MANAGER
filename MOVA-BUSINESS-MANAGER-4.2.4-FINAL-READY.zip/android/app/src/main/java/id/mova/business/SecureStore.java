package id.mova.business;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import android.util.Base64;
import java.security.KeyStore;

public final class SecureStore {
    private static final String KS="AndroidKeyStore";
    private static final String ALIAS="mova_secure_store_v1";
    private final SharedPreferences prefs;

    public SecureStore(Context context){
        prefs=context.getSharedPreferences("mova_secure_store",Context.MODE_PRIVATE);
        ensureKey();
    }
    private void ensureKey(){
        try{
            KeyStore ks=KeyStore.getInstance(KS);
            ks.load(null);
            if(!ks.containsAlias(ALIAS)){
                KeyGenerator kg=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,KS);
                kg.init(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
                        .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                        .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());
                kg.generateKey();
            }
        }catch(Exception e){throw new IllegalStateException("SecureStore unavailable",e);}
    }
    private SecretKey key() throws Exception{
        KeyStore ks=KeyStore.getInstance(KS);
        ks.load(null);
        return ((KeyStore.SecretKeyEntry)ks.getEntry(ALIAS,null)).getSecretKey();
    }
    public void put(String name,String value){
        try{
            Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,key());
            prefs.edit().putString(name,Base64.encodeToString(c.getIV(),Base64.NO_WRAP)+":"+Base64.encodeToString(c.doFinal(value.getBytes(java.nio.charset.StandardCharsets.UTF_8)),Base64.NO_WRAP)).apply();
        }catch(Exception e){throw new IllegalStateException(e);}
    }
    public String get(String name){
        try{
            String saved=prefs.getString(name,null);if(saved==null)return null;
            String[] parts=saved.split(":",2);if(parts.length!=2)return null;
            byte[] iv=Base64.decode(parts[0],Base64.NO_WRAP), data=Base64.decode(parts[1],Base64.NO_WRAP);
            Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,iv));
            return new String(c.doFinal(data),java.nio.charset.StandardCharsets.UTF_8);
        }catch(Exception e){return null;}
    }
    public void remove(String name){prefs.edit().remove(name).apply();}
}
