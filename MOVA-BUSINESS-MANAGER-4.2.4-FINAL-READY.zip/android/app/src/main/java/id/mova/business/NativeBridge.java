package id.mova.business;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Toast;
import android.print.PrintManager;
import android.print.PrintDocumentAdapter;
import android.view.View;
import android.speech.tts.TextToSpeech;
import org.json.JSONObject;
import org.json.JSONArray;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Locale;
import java.util.UUID;

public final class NativeBridge {
    private final Context context;
    private final WebView webView;
    private final SecureStore secure;
    private final BillingManager billing;
    private TextToSpeech tts;

    public NativeBridge(android.app.Activity context,WebView webView){
        this.context=context;this.webView=webView;this.secure=new SecureStore(context);
        this.billing=new BillingManager(context,new BillingManager.Listener(){@Override public void onPurchase(String productId,String purchaseToken){String payload="{\"productId\":\""+escape(productId)+"\",\"purchaseToken\":\""+escape(purchaseToken)+"\"}";webView.post(()->webView.evaluateJavascript("window.dispatchEvent(new CustomEvent(\'mova-pro-purchase\',{detail:"+payload+"}));",null));} @Override public void onBillingError(String message){webView.post(()->android.widget.Toast.makeText(context,message,android.widget.Toast.LENGTH_LONG).show());}});
        this.billing.setActivity(context);
        tts=new TextToSpeech(context,status->{if(status==TextToSpeech.SUCCESS)tts.setLanguage(new Locale("id","ID"));});
    }
    private JSONObject obj(String json){try{return new JSONObject(json==null?"{}":json);}catch(Exception e){return new JSONObject();}}

    @JavascriptInterface public String announcePayment(String json){
        try{String text=obj(json).optString("text","Pembayaran diterima");tts.speak(text,TextToSpeech.QUEUE_FLUSH,null,"mova-payment",null);return "{\"ok\":true}";}
        catch(Exception e){return "{\"ok\":false,\"error\":\"tts\"}";}
    }
    @JavascriptInterface public String verifyPayment(String json){
        JSONObject i=obj(json);
        try{
            i.put("verified",false);
            i.put("verification_status","notification_verified");
            i.put("source",i.optString("source","native_notification"));
        }catch(Exception ignored){}
        return i.toString();
    }
    @JavascriptInterface public String getDeviceId(String ignored){
        String id=secure.get("device_id");
        if(id==null){id=UUID.randomUUID().toString();secure.put("device_id",id);}return "{\"device_id\":\""+id+"\"}";
    }
    @JavascriptInterface public String getDeviceRole(String ignored){return "{\"role\":\""+role()+"\"}";}
    @JavascriptInterface public String setDeviceRole(String json){String r=obj(json).optString("role","cashier");if(!r.matches("owner|cashier|payment_terminal|viewer"))r="cashier";secure.put("device_role",r);return getDeviceRole("");}
    @JavascriptInterface public String isAndroidShell(String ignored){return "true";}
    @JavascriptInterface public String openAuthUrl(String json){
        try{
            String url=obj(json).optString("url","");
            if(url.isEmpty())return "{\"ok\":false,\"error\":\"url_required\"}";
            Intent intent=new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            intent.addCategory(Intent.CATEGORY_BROWSABLE);
            context.startActivity(intent);
            return "{\"ok\":true}";
        }catch(Exception e){return "{\"ok\":false,\"error\":\"browser_unavailable\"}";}
    }
    @JavascriptInterface public String purchasePro(String json){String product=obj(json).optString("productId","mova_pro_monthly");billing.purchase(product);return "{\"ok\":true}";}
    @JavascriptInterface public String acknowledgeProPurchase(String json){billing.acknowledge(obj(json).optString("purchaseToken",""));return "{\"ok\":true}";}
    @JavascriptInterface public String secureStore(String json){JSONObject i=obj(json);String key=i.optString("key");String action=i.optString("action","get");if(key.isEmpty())return "{}";if("put".equals(action)){secure.put(key,i.optString("value"));return "{\"ok\":true}";}if("delete".equals(action)){secure.remove(key);return "{\"ok\":true}";}String v=secure.get(key);return "{\"value\":"+(v==null?"null":"\""+escape(v)+"\"")+"}";}
    @JavascriptInterface public String shareReceipt(String json){
        try{
            String text=obj(json).optString("text","Struk MŌVA");
            Intent send=new Intent(Intent.ACTION_SEND);
            send.setType("text/plain");
            send.putExtra(Intent.EXTRA_TEXT,text);
            context.startActivity(Intent.createChooser(send,"Bagikan struk MŌVA"));
            return "{\"ok\":true}";
        }catch(Exception e){return "{\"ok\":false,\"error\":\"share_failed\"}";}
    }
    @JavascriptInterface public String printReceipt(String json){
        try{
            String html=obj(json).optString("html","");
            if(html.isEmpty())return "{\"ok\":false,\"reason\":\"html_required\"}";
            final WebView printerView=new WebView(context);
            printerView.getSettings().setJavaScriptEnabled(false);
            printerView.loadDataWithBaseURL(null,html,"text/html","UTF-8",null);
            printerView.setVisibility(View.INVISIBLE);
            printerView.setLayerType(View.LAYER_TYPE_SOFTWARE,null);
            printerView.postDelayed(()->{
                try{
                    PrintManager pm=(PrintManager)context.getSystemService(Context.PRINT_SERVICE);
                    PrintDocumentAdapter adapter=printerView.createPrintDocumentAdapter("MŌVA Receipt");
                    pm.print("MŌVA Receipt",adapter,null);
                }catch(Exception ignored){}
            },350);
            return "{\"ok\":true}";
        }catch(Exception e){return "{\"ok\":false,\"error\":\"print_failed\"}";}
    }
    @JavascriptInterface public String openNotificationAccess(String ignored){context.startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));return "{\"ok\":true}";}
    @JavascriptInterface public String setAllowedPackages(String json){String list=obj(json).optString("packages","");secure.put("allowed_notification_packages",list);return "{\"ok\":true}";}
    @JavascriptInterface public String getNativeStatus(String ignored){return "{\"native\":true,\"targetSdk\":36,\"role\":\""+role()+"\",\"notificationAccess":"+hasListener()+"}";}
    @JavascriptInterface public String getPaymentEvents(String ignored){
        String raw=secure.get("payment_event_queue");
        secure.remove("payment_event_queue");
        return raw==null?"[]":raw;
    }
    private String role(){String r=secure.get("device_role");return r==null?"cashier":r;}
    public String allowedPackages(){String p=secure.get("allowed_notification_packages");return p==null?"":p;}
    private boolean hasListener(){String enabled=android.provider.Settings.Secure.getString(context.getContentResolver(),"enabled_notification_listeners");return enabled!=null&&enabled.contains(context.getPackageName());}
    private static String escape(String s){return s.replace("\\","\\\\").replace("\"","\\\"");}
    public void refreshPurchases(){billing.queryActive();}
    public void destroy(){if(tts!=null){tts.stop();tts.shutdown();}billing.destroy();}
}
