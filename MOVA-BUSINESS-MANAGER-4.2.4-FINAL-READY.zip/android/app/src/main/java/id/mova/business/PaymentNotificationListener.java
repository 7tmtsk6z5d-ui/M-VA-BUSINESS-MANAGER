package id.mova.business;

import android.app.Notification;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;

import org.json.JSONObject;

import java.text.NumberFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.ArrayList;
import org.json.JSONArray;

public class PaymentNotificationListener extends NotificationListenerService {
    private static final Pattern RP=Pattern.compile("(?i)(?:rp|idr)\\s*[.]?\\s*([0-9][0-9.,]*)");
    private static final long DUP_MS=120000;
    private final Map<String,Long> seen=new HashMap<>();
    private SecureStore secure;
    private TextToSpeech tts;

    @Override public void onListenerConnected(){secure=new SecureStore(getApplicationContext());tts=new TextToSpeech(getApplicationContext(),status->{if(status==TextToSpeech.SUCCESS)tts.setLanguage(new Locale("id","ID"));});}

    @Override public void onNotificationPosted(StatusBarNotification sbn){
        if(secure==null)return;
        if(!isAllowed(sbn.getPackageName()))return;
        Notification n=sbn.getNotification();Bundle b=n.extras;if(b==null)return;
        String title=String.valueOf(b.getCharSequence(Notification.EXTRA_TITLE,""));
        String text=String.valueOf(b.getCharSequence(Notification.EXTRA_TEXT,""));
        String combined=(title+" "+text).replaceAll("\\s+"," ").trim();
        if(combined.isEmpty()||!positivePaymentSignal(combined)||negativePaymentSignal(combined))return;
        double amount=parseAmount(combined);if(amount<=0)return;
        String fp=sbn.getPackageName()+"|"+title+"|"+text+"|"+sbn.getPostTime();
        long now=System.currentTimeMillis();
        seen.entrySet().removeIf(e->now-e.getValue()>DUP_MS);
        if(seen.containsKey(fp))return;
        seen.put(fp,now);
        JSONObject event=new JSONObject();try{
            event.put("provider",sbn.getPackageName());event.put("reference",title);event.put("amount",amount);event.put("timestamp",sbn.getPostTime());event.put("source","native_notification");event.put("verified",false);event.put("raw",combined);
            String json=event.toString();
            if(!MainActivity.foreground && "payment_terminal".equals(secure.get("device_role")) && "true".equals(secure.get("pro_enabled"))){
                tts.speak("Pembayaran diterima " + formatRupiah(amount),TextToSpeech.QUEUE_FLUSH,null,"mova-payment",null);
            }
            if(!MainActivity.foreground)queueEvent(json);
            sendToWeb(json);
        }catch(Exception ignored){}
    }
    private boolean isAllowed(String pkg){String raw=secure.get("allowed_notification_packages");if(raw==null||raw.isBlank())return false;for(String p:raw.split(",")){if(pkg.equals(p.trim()))return true;}return false;}
    private boolean positivePaymentSignal(String s){String x=s.toLowerCase(Locale.ROOT);return x.contains("diterima")||x.contains("masuk")||x.contains("pembayaran")||x.contains("payment received")||x.contains("received");}
    private boolean negativePaymentSignal(String s){String x=s.toLowerCase(Locale.ROOT);return x.contains("dikirim")||x.contains("keluar")||x.contains("dibayar")||x.contains("refund")||x.contains("pengeluaran");}
    private double parseAmount(String s){Matcher m=RP.matcher(s);if(!m.find())return 0;String n=m.group(1).replace(".","").replace(",","");try{return Double.parseDouble(n);}catch(Exception e){return 0;}}
    private String formatRupiah(double amount){return NumberFormat.getIntegerInstance(new Locale("id","ID")).format(Math.round(amount)).replace("\u00A0"," ").replace(",",".");}
    private void queueEvent(String json){
        try{
            String raw=secure.get("payment_event_queue");
            JSONArray arr=raw==null?new JSONArray():new JSONArray(raw);
            arr.put(json);
            while(arr.length()>30)arr.remove(0);
            secure.put("payment_event_queue",arr.toString());
        }catch(Exception ignored){}
    }
    private void sendToWeb(String json){
        // This service does not own a WebView. MainActivity is the foreground consumer.
        PaymentEventBus.publish(this,json);
    }
    @Override public void onDestroy(){if(tts!=null){tts.stop();tts.shutdown();}super.onDestroy();}
}
