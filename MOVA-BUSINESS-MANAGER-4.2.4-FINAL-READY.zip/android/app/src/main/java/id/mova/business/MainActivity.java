package id.mova.business;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import org.json.JSONObject;

public class MainActivity extends Activity implements PaymentEventBus.Listener {
    public static volatile boolean foreground=false;
    private WebView webView;
    private NativeBridge bridge;
    private String pendingAuthUrl;
    private boolean pageReady=false;

    @Override protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        foreground=true;
        webView=new WebView(this);
        setContentView(webView);
        WebSettings s=webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        webView.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView view,String url){
                if(isAuthDeepLink(url)){ dispatchAuthUrl(url); return true; }
                if(url.startsWith("file:///android_asset/") || url.startsWith("about:")) return false;
                try{ startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }catch(Exception ignored){}
                return true;
            }
            @Override public void onPageFinished(WebView view,String url){
                super.onPageFinished(view,url);
                pageReady=true;
                if(pendingAuthUrl!=null){ String u=pendingAuthUrl; pendingAuthUrl=null; dispatchAuthUrl(u); }
            }
        });
        webView.setWebChromeClient(new WebChromeClient());
        bridge=new NativeBridge(this,webView);
        webView.addJavascriptInterface(bridge,"MovaNative");
        webView.loadUrl("file:///android_asset/web/index.html");
        PaymentEventBus.register(this);
        handleIntent(getIntent());
    }

    @Override protected void onNewIntent(Intent intent){
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    private void handleIntent(Intent intent){
        if(intent==null)return;
        Uri data=intent.getData();
        if(data!=null && isAuthDeepLink(data.toString())) dispatchAuthUrl(data.toString());
    }

    private boolean isAuthDeepLink(String url){
        try{
            Uri u=Uri.parse(url);
            return "mova".equalsIgnoreCase(u.getScheme()) && "auth".equalsIgnoreCase(u.getHost()) && "/callback".equals(u.getPath());
        }catch(Exception e){return false;}
    }

    private void dispatchAuthUrl(String url){
        if(webView==null || !pageReady){ pendingAuthUrl=url; return; }
        webView.post(()->{
            String payload=JSONObject.quote(url==null?"":url);
            webView.evaluateJavascript("window.MovaAuth&&window.MovaAuth.handleDeepLink("+payload+");",null);
        });
    }

    @Override public void onPayment(String json){
        runOnUiThread(()->webView.evaluateJavascript("window.dispatchEvent(new CustomEvent('mova-payment-event',{detail:JSON.parse("+JSONObject.quote(json)+")}));",null));
    }

    @Override protected void onPause(){super.onPause();foreground=false;}
    @Override protected void onResume(){super.onResume();foreground=true;if(bridge!=null)bridge.refreshPurchases();}
    @Override protected void onDestroy(){foreground=false;PaymentEventBus.unregister(this);if(bridge!=null)bridge.destroy();if(webView!=null)webView.destroy();super.onDestroy();}
    @Override public void onBackPressed(){if(webView!=null&&webView.canGoBack())webView.goBack();else super.onBackPressed();}
}
